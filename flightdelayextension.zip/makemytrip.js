
var handleFlightNumberClick = function(event) {
	console.log(event);
	console.log(event.path[0].innerText);
	var previousDivs = event.path[3].getElementsByClassName('flight-details-div');
	if (previousDivs.length === 0) {
		event.path[3].innerHTML += '<div id = "flight-delay-details" class = "flight-details-div">LOADING FLIGHT DELAYS</div>';


		chrome.runtime.sendMessage({flightDetails: event.path[0].innerText}, function(response) {
			console.log(response);

			var loadingDiv = event.path[3].getElementsByClassName('flight-details-div');
			if (loadingDiv.length !== 0) {
				event.path[3].removeChild(loadingDiv[0]);
			}
			event.path[3].innerHTML += '<div id = "flight-delay-details" class = "flight-details-div">'+response.details+'</div>';
		});
	}
};

var updateMouseOverListeners = function() {
	var elements = document.getElementsByClassName('flt_number');
	var elements600 = document.getElementsByClassName('flt_number_less600');
	
	var elestring = [];
	
	for(var i = 0; i < elements.length; i++) {
		elestring.push(elements[i].innerHTML);

		elements[i].addEventListener("mouseover", handleFlightNumberClick);
	}

	for(var i = 0; i < elements600.length; i++) {

		elements600[i].addEventListener("mouseover", handleFlightNumberClick);
	}
	setTimeout(updateMouseOverListeners, 1000);
}

updateMouseOverListeners();