

chrome.runtime.onMessage.addListener(
  function(request, sender, sendResponse) {

  	var handleStateChange = function() {
		  
	if(this.readyState == 4 && this.status == 200) {
	    var parser = new DOMParser();
	    var doc = parser.parseFromString(this.responseText, "text/html");
	     
	    var response = doc.getElementsByClassName('uiComponent300')[0];

	    var imageURL = response.getElementsByTagName('img')[0].getAttribute('src');
	    response.getElementsByTagName('img')[0].src = "http://www.flightstats.com" + imageURL;

	    var unnecessaryHeader = response.childNodes[3].childNodes[1];
	    response.childNodes[3].removeChild(unnecessaryHeader);
	    sendResponse({details: response.innerHTML});
	   	}
  	};

  	var airline = request.flightDetails.substring(0,2);
  	var flightNumber = request.flightDetails.substring(3);
  	var xhr = new XMLHttpRequest();
  	xhr.onreadystatechange = handleStateChange; // Implemented elsewhere.
  	xhr.open("GET", 'http://www.flightstats.com/go/FlightRating/flightRatingByFlight.do?airline='+airline+'&flightNumber='+flightNumber, true);
  	xhr.send();

  	return true;
});